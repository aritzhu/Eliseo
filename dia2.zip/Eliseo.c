#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include "colaDato.h"



void recogerDatos(tipoCola *, FILE *);


int main(){



    //recogerDatos
    tipoCola c;
    nuevaCola(&c);


    FILE* fichero;
    fichero = fopen("bald_probability.csv","r");


        recogerDatos(&c,fichero);





    //while(!feof(fichero)){






    //normalizar
    //calcularDistancia




    return 0;
}

void recogerDatos(tipoCola *c, FILE *f){

    printf("sdg\n");
    char a[150],a_copy[150],aux[50];
    char* lineaDatos,*fallos;
    tipoElementoCola e;
    int pos,tam;
    int cont = 0;
    //ignoramos nombres columna
    fgets(a,150,f);

    while(!feof(f)){

        //leemos fila
        fgets(a,150,f);
        pos = 0;
        tam = strlen(a);
        strcpy(a_copy,a);

        int fallo = 0;
        for(int i = 0;i<150;i++){
            if(a[i]==','){
                if(a[i+1]==','){
                    fallo++;
                }
            }
        }

        if(fallo < 1 && a[0] != ','){
        //edad
            e.age = 0;


            lineaDatos = strtok(a,",");
            for(int i = 0; i < strlen(lineaDatos);i++){
                e.age = e.age*10 + *(lineaDatos+i)-'0';
            }
            printf("%d ",e.age);



        //genero hombre mujer

            lineaDatos = strtok(NULL,",");
            e.gender = *lineaDatos == 'm';
            printf("%d ",e.gender);




        //job_role G == 2 E == 1 else == 0
        e.job_role = 0;

            lineaDatos = strtok(NULL,",");
            e.job_role = (*lineaDatos == 'G')+ (*lineaDatos == 'G')+ (*lineaDatos == 'E');
            printf("%d ",e.job_role);




        //province

            lineaDatos = strtok(NULL,",");



        //salary
            e.salary = 0;

            lineaDatos = strtok(NULL,",");

            for(int i = 0; *(lineaDatos + i) !='.';i++){
                e.salary = (float)(e.salary*10 + *(lineaDatos+i)-'0');
            }
            printf("%d ",e.salary);




        //is_married

            lineaDatos = strtok(NULL,",");
            e.is_married = *lineaDatos-'0';
            printf("%d ",e.is_married);




        //is_hereditary

            lineaDatos = strtok(NULL,",");
            e.is_hereditary = *lineaDatos-'0';
            printf("%d ",e.is_hereditary);




        //weight

            lineaDatos = strtok(NULL,",");
            e.weight = 0;
            for(int i = 0; *(lineaDatos + i) !='.';i++){
                e.weight = (e.weight*10 + *(lineaDatos+i)-'0');
            }
            printf("%d ",e.weight);




        //height

            lineaDatos = strtok(NULL,",");
            e.height = 0;
            for(int i = 0; *(lineaDatos + i) !='.';i++){
                e.height = (e.height*10 + *(lineaDatos+i)-'0');
            }
            printf("%d ",e.height);



        //etxabe lloron

            lineaDatos = strtok(NULL,",");



        //is_smoker

            lineaDatos = strtok(NULL,",");
            e.is_smoker = *lineaDatos-'0';
            printf("%d ",e.is_smoker);




        //poch

            lineaDatos = strtok(NULL,",");



        //stres

            lineaDatos = strtok(NULL,",");
            e.stress = 0;
            for(int i = 0;i < strlen(lineaDatos);i++){
                e.stress = (e.stress*10 + *(lineaDatos+i)-'0');
            }

            printf("%d ",e.stress);

        //JORITZ

            lineaDatos = strtok(NULL,",");
            e.bald = *lineaDatos-'0';
            printf("%d ",e.bald);
            printf("\n");
        }
        cont++;
        printf("%d \n",cont);

        //encolar(c,e);
    }

    //while(!esNulaCola(*c)){
        //e = frente(*c);
        //printf("%d",e.age);
        //desencolar(c);
    //}

}
    //printf("%d\n",e.age);



//     while(!esNulaCola(*c)){
//
//         aux = frente(*c);
//         desencolar(c);
//         printf("%d",aux.age);
//     }


//}
