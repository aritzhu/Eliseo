#include <stdbool.h>

typedef struct dato{
	int age;
	int gender;
	char job_role;
	int salary;
	int is_married;
	int is_hereditary;
	int weight;
	int height;
	int is_smoker;
	int stress;
	int bald;
}tipoElementoCola;

typedef struct celdaC{
	tipoElementoCola elem;
	struct celdaC* sig;
} celdaCola; 

typedef struct tipoC{
	celdaCola* ini;
	celdaCola* fin;
}tipoCola;

void nuevaCola(tipoCola*);

bool esNulaCola(tipoCola);

void encolar(tipoCola*, tipoElementoCola);

void desencolar(tipoCola*);

tipoElementoCola frente(tipoCola);


