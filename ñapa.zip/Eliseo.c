#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include "colaDato.h"



void recogerDatos(tipoCola *, FILE *);


int main(){


    //recogerDatos
    tipoCola c;
    nuevaCola(&c);


    FILE* fichero;
    fichero = fopen("bald_probability.csv","r");
    recogerDatos(&c,fichero);




    //while(!feof(fichero)){






    //normalizar
    //calcularDistancia



















    return 0;
}

void recogerDatos(tipoCola *c, FILE *f){

    char a[150];
    tipoElementoCola e;



    //saltamos primera fila
    fgets(a,150,f);
    printf("%s",a);


    //recogemos todos los demas recogerDatos
   //while(!feof(f)){
        fgets(a,150,f);
        int i = 0;
        e.age = 0.;
        while(a[i]!= ','){
            e.age = e.age*10+a[i]-'0';
            i++;
            //printf("%d ",e.age);
        }
        i++;
        e.gender = a[i] == 'm';
        while(a[i]!=','){
            i++;
        }
        i++;
        e.job_role = a[i];
        while(a[i]!= ','){
            i++;
        }i++;
        while(a[i]!= ','){
            i++;
        }i++;
        e.salary = 0;
        while(a[i]!= '.' && a[i]!= ','){
            e.salary = e.salary*10+a[i]-'0';
            i++;
        }
        while(a[i]!= ','){
            i++;
        }i++;
        e.is_married = a[i]-'0';
        i++;
        e.weight = 0;
        while(a[i]!= '.' && a[i]!= ','){
            e.weight = e.weight*10+a[i]-'0';
            i++;
        }while(a[i]!= ','){
            i++;
        }i++;
        e.height = 0;
        while(a[i]!= '.' && a[i]!= ','){
            e.height = e.height*10+a[i]-'0';
            i++;
        }while(a[i]!= ','){
            i++;
        }i++;
        while(a[i]!= ','){
            i++;
        }i++;
        e.is_smoker = a[i]-'0';
        while(a[i]!= ','){
            i++;
        }i++;
        e.stress = 0;
        while(a[i]!= ','){
            e.stress = e.stress*10+a[i]-'0';
            i++;
        }
        e.bald = a[i]-'0';
        encolar(c,e);
        printf("%d espasmo ",e.age);
    //}


    tipoElementoCola aux;
    while(!esNulaCola(*c)){


        aux = frente(*c);
        desencolar(c);
        printf("%f",&aux.age);
    }


}
