#include <stdbool.h>

typedef struct dato{
	float age;
	float gender;
	char job_role;
	float salary;
	float is_married;
	float is_hereditary;
	float weight;
	float height;
	float is_smoker;
	float stress;
	float bald;
}elemento;

typedef elemento* tipoElementoCola;

typedef struct celdaC{
	tipoElementoCola elem;
	struct celdaC* sig;
} celdaCola; 

typedef struct tipoC{
	celdaCola* ini;
	celdaCola* fin;
}tipoCola;

void nuevaCola(tipoCola*);

bool esNulaCola(tipoCola);

void encolar(tipoCola*, tipoElementoCola);

void desencolar(tipoCola*);

tipoElementoCola frente(tipoCola);


