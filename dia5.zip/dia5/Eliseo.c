#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include "colaDato.h"

#define N_MUESTRAS 500

typedef struct eliseo{
    bool calvo;
    float distancia;
}eliseo;

void recogerDatos(tipoCola *, FILE *);
void normalizar(tipoCola *);
int Fmax(int, int);
int Fmin(int, int);
eliseo calcularDistancia(tipoElementoCola , tipoCola* );
float absoluto(float );
void calcularDistanciaKNN(tipoElementoCola , tipoCola*);
int posicionMaxima(eliseo*,int);

int main(){
    tipoCola c;
    nuevaCola(&c);

    FILE* fichero;
    fichero = fopen("bald_probability.csv","r");

    char op;
    printf("quieres introducir tus datos?(s/n)\n");
    scanf(" %c",&op);

    if(op == 'n'){
        //Se recogen los datos
        recogerDatos(&c,fichero);
        //Se normalizan los datos
        normalizar(&c);

        tipoCola c_muestra;
        nuevaCola(&c_muestra);

        for(int i = 0; i< N_MUESTRAS;i++){
            tipoElementoCola m;
            m = (tipoElementoCola)malloc(sizeof(elemento));
            m = frente(c);
            encolar(&c_muestra,m);
            desencolar(&c);
        }

        tipoElementoCola elem_muestra;
            int resultado = 0;
            eliseo res;
        for(int i = 0; i< N_MUESTRAS;i++){
            elem_muestra = (tipoElementoCola)malloc(sizeof(elemento));
            elem_muestra = frente(c_muestra);
            desencolar(&c_muestra);

            res = calcularDistancia(elem_muestra,&c);
            resultado = resultado + (res.calvo == elem_muestra->bald);
        }
        resultado = 100*resultado/N_MUESTRAS;
        printf("El porcentaje de aciertos es del %d%%\n",resultado);

    }else{
        tipoElementoCola e;
        e = (tipoElementoCola)malloc(sizeof(elemento));
        printf("Cuantos años tienes?:\n");
        scanf(" %f",&((e)->age));
        printf("introduce salario (en €):\n");
        scanf(" %f",&(e)->salary);
        e->salary *= 16800;
        printf("introduce peso:\n");
        scanf(" %f",&(e)->weight);
        printf("introduce altura:\n");
        scanf(" %f",&(e)->height);
        printf("introduce nivel de stres de (1,10):\n");
        scanf(" %f",&(e)->stress);
        printf("Fumas? (0 no, 1 si)\n");
        scanf(" %f",&(e)->is_smoker);
        printf("Heredas la alopecia? (0 no heredas, 1 heredas):\n");
        scanf(" %f",&(e)->is_hereditary);
        printf("Estas casado/a? (0 no, 1 si)\n");
        scanf(" %f",&(e)->is_married);
        printf("Eres hombre o mujer? (0 mujer, 1 hombre)\n");
        scanf(" %f",&(e)->gender);

        encolar(&c,e);
        recogerDatos(&c,fichero);
        normalizar(&c);//datos normalizados

        tipoCola c_muestra;
        nuevaCola(&c_muestra);

        tipoElementoCola m;
        m = (tipoElementoCola)malloc(sizeof(elemento));
        m = frente(c);
        encolar(&c_muestra,m);
        desencolar(&c);

        tipoElementoCola elem_muestra;
        int resultado = 0;
        eliseo res;

        printf("quieres k == 1 (s/n)");
        scanf(" %c",&op);
        if(op == 'n'){
            calcularDistanciaKNN(m,&c);
        }
        else{
            eliseo res = calcularDistancia(m,&c);
        }
    }
    return 0;
}

void recogerDatos(tipoCola *c, FILE *f){
    char a[150],a_copy[150],aux[50];
    char* lineaDatos,*fallos;
    tipoElementoCola e;
    int pos,tam;
    int cont = 0;
    //ignoramos nombres columna
    fgets(a,150,f);
    tipoElementoCola auxelem;
    auxelem = (tipoElementoCola)malloc(sizeof(elemento));

    while(!feof(f) && cont < 1300){
        //leemos fila
        fgets(a,150,f);
        pos = 0;
        tam = strlen(a);
        strcpy(a_copy,a);

        int fallo = 0;
        for(int i = 0;i<150;i++){
            if(a[i]==','){
                if(a[i+1]==','){
                    fallo++;
                }
            }
        }
        if(fallo < 1 && a[0] != ','){
            e = (tipoElementoCola)malloc(sizeof(elemento));

            //edad
            e->age = 0;
            lineaDatos = strtok(a,",");
            for(int i = 0; i < strlen(lineaDatos);i++){
                e->age = e->age*10 + *(lineaDatos+i)-'0';
            }
            //genero hombre mujer
            lineaDatos = strtok(NULL,",");
            e->gender = *lineaDatos == 'm';

            //job_role G == 2 E == 1 else == 0
            e->job_role = 0;

            lineaDatos = strtok(NULL,",");
            e->job_role = (*lineaDatos == 'G')+ (*lineaDatos == 'G')+ (*lineaDatos == 'E');

            //province
            lineaDatos = strtok(NULL,",");

            //salary
            e->salary = 0;
            lineaDatos = strtok(NULL,",");
            for(int i = 0; *(lineaDatos + i) !='.';i++){
                e->salary = (float)(e->salary*10 + *(lineaDatos+i)-'0');
            }

            //is_married
            lineaDatos = strtok(NULL,",");
            e->is_married = *lineaDatos-'0';

            //is_hereditary
            lineaDatos = strtok(NULL,",");
            e->is_hereditary = *lineaDatos-'0';

            //weight
            lineaDatos = strtok(NULL,",");
            e->weight = 0;
            for(int i = 0; *(lineaDatos + i) !='.';i++){
                e->weight = (e->weight*10 + *(lineaDatos+i)-'0');
            }

            //height
            lineaDatos = strtok(NULL,",");
            e->height = 0;
            for(int i = 0; *(lineaDatos + i) !='.';i++){
                e->height = (e->height*10 + *(lineaDatos+i)-'0');
            }

            //etxabe lloron
            lineaDatos = strtok(NULL,",");

            //is_smoker
            lineaDatos = strtok(NULL,",");
            e->is_smoker = *lineaDatos-'0';

            //poch
            lineaDatos = strtok(NULL,",");

            //stress
            lineaDatos = strtok(NULL,",");
            e->stress = 0;
            for(int i = 0;i < strlen(lineaDatos);i++){
                e->stress = (e->stress*10 + *(lineaDatos+i)-'0');
            }

            //JORITZ
            lineaDatos = strtok(NULL,",");
            e->bald = *lineaDatos-'0';
            encolar(c,e);
            auxelem = frente(*c);
        }
        cont++;
    }
}

void normalizar(tipoCola *c){
    tipoCola c_copy;
    nuevaCola(&c_copy);
    elemento max,min;
    tipoElementoCola muestra;
    muestra = (tipoElementoCola)malloc(sizeof(elemento));
    //inicializar max y min;
    if(!esNulaCola(*c)){
        muestra = frente(*c);
        desencolar(c);
        encolar(&c_copy,muestra);
    }

    max.age = muestra->age;
    max.salary = muestra->salary;
    max.weight = muestra->weight;
    max.height = muestra->height;
    max.stress = muestra->stress;

    min.age = muestra->age;
    min.salary = muestra->salary;
    min.weight = muestra->weight;
    min.height = muestra->height;
    min.stress = muestra->stress;

    while(!esNulaCola(*c)){
        muestra = frente(*c);
        desencolar(c);
        encolar(&c_copy,muestra);

        max.age = Fmax(muestra->age,max.age);
        max.salary = Fmax(muestra->salary,max.salary);
        max.weight = Fmax(muestra->weight,max.weight);
        max.height = Fmax(muestra->height,max.height);
        max.stress = Fmax(muestra->stress,max.stress);

        min.age = Fmin(muestra->age,min.age);
        min.salary = Fmin(muestra->salary,min.salary);
        min.weight = Fmin(muestra->weight,min.weight);
        min.height = Fmin(muestra->height,min.height);
        min.stress = Fmin(muestra->stress,min.stress);
    }

    while(!esNulaCola(c_copy)){
        muestra = frente(c_copy);
        desencolar(&c_copy);

        muestra->age = (muestra->age - min.age)/(max.age-min.age);
        muestra->salary = (muestra->salary - min.salary)/(max.salary-min.salary);
        muestra->weight = (muestra->weight - min.weight)/(max.weight-min.weight);
        muestra->height = (muestra->height - min.height)/(max.height-min.height);
        muestra->stress = (muestra->stress - min.stress)/(max.stress-min.stress);

        encolar(c,muestra);
    }
}

int Fmax(int a, int b){
    if(a < b){
        return b;
    }else{
        return a;
    }
}

int Fmin(int a, int b){
    if(a > b){
        return b;
    }else{
        return a;
    }
}


eliseo calcularDistancia(tipoElementoCola e, tipoCola* c){
    tipoCola c_copy;
    nuevaCola(&c_copy);
    eliseo resultado;

    tipoElementoCola elem;
    elemento aux;
    float distancia;

    resultado.distancia = 10;

    while(!esNulaCola(*c) && resultado.distancia != 0){
        elem = (tipoElementoCola)malloc(sizeof(elemento));
        elem = frente(*c);
        desencolar(c);
        encolar(&c_copy,elem);

        aux.age = absoluto(elem->age-e->age);
        aux.salary = absoluto(elem->salary-e->salary);
        aux.weight = absoluto(elem->weight-e->weight);
        aux.height = absoluto(elem->height-e->height);
        aux.stress = absoluto(elem->stress-e->stress);
        aux.is_married = absoluto(elem->is_married - e->is_married);
        aux.is_hereditary = absoluto(elem->is_hereditary-e->is_hereditary);
        aux.is_smoker = absoluto(elem->is_smoker - e->is_smoker);
        aux.gender = absoluto(elem->gender - e->gender);

        distancia = sqrt(aux.age*aux.age+aux.salary*aux.salary+aux.weight*aux.weight+aux.height*aux.height+aux.stress*aux.stress+aux.is_married*aux.is_married+aux.is_hereditary*aux.is_hereditary+aux.is_smoker*aux.is_smoker+aux.gender*aux.gender);
        if(resultado.distancia >= distancia){
            resultado.distancia = distancia;
            resultado.calvo = elem->bald;
        }
    }

    while(!esNulaCola(c_copy)){
        elem = frente(c_copy);
        desencolar(&c_copy);
        encolar(c,elem);
    }
    return resultado;
}

float absoluto(float a){
    if(a < 0){
        return -a;
    }else{
        return a;
    }
}

void calcularDistanciaKNN(tipoElementoCola e, tipoCola* c){
    int k;
    printf("para que k quieres hacer este problema?\n");
    scanf(" %d",&k);

    eliseo *respuestas;
    respuestas = (eliseo*)malloc(sizeof(eliseo)*k);
    int posMax;

    tipoCola c_copy;
    nuevaCola(&c_copy);
    eliseo resultado;

    tipoElementoCola elem;
    elemento aux;
    float distancia;

    for(int i = 0; i< k; i++){
    respuestas[i].distancia = 10;}

    posMax = posicionMaxima(respuestas,k);
    while(!esNulaCola(*c) && respuestas[posMax].distancia != 0){
        elem = (tipoElementoCola)malloc(sizeof(elemento));
        elem = frente(*c);
        desencolar(c);
        encolar(&c_copy,elem);

        aux.age = absoluto(elem->age-e->age);
        aux.salary = absoluto(elem->salary-e->salary);
        aux.weight = absoluto(elem->weight-e->weight);
        aux.height = absoluto(elem->height-e->height);
        aux.stress = absoluto(elem->stress-e->stress);
        aux.is_married = absoluto(elem->is_married - e->is_married);
        aux.is_hereditary = absoluto(elem->is_hereditary-e->is_hereditary);
        aux.is_smoker = absoluto(elem->is_smoker - e->is_smoker);
        aux.gender = absoluto(elem->gender - e->gender);

        distancia = sqrt(aux.age*aux.age+aux.salary*aux.salary+aux.weight*aux.weight+aux.height*aux.height+aux.stress*aux.stress+aux.is_married*aux.is_married+aux.is_hereditary*aux.is_hereditary+aux.is_smoker*aux.is_smoker+aux.gender*aux.gender);
        if(respuestas[posMax].distancia >= distancia){
            respuestas[posMax].distancia = distancia;
            respuestas[posMax].calvo = elem->bald;
        }
        posMax = posicionMaxima(respuestas,k);
    }
    int resFinal = 0;
    printf("Las k distancias obtenidas son:\n");
    for(int i = 0; i< k; i++){
        printf("Distancia Nº %d: %f, %d\n", i, respuestas[i].distancia, respuestas[i].calvo);
        resFinal += respuestas[i].calvo;
    }
    if(resFinal > k/2){
        printf("Tal y como se esperaba, vas a quedarte calvo.\n");
    }
    else if(resFinal == k/2){
        int posMin = 0;
        for(int i = 1; i< k;i++){
            if(respuestas[i].distancia < respuestas[posMin].distancia){
                posMin = i;
            }
        }
        if(respuestas[posMin].calvo == 1){
            printf("Parecia que te salvabas, pero no compañero... JAJAJA.\n");
        }
        else{
            printf("Parecia que te salvabas, y en efecto te has salvado.\n");
        }
    }
    else{
        printf("Enhorabuena, mantienes tu pelo.\n");
    }

    while(!esNulaCola(c_copy)){
        elem = frente(c_copy);
        desencolar(&c_copy);
        encolar(c,elem);
    }
}

int posicionMaxima(eliseo a[],int k){
    int posMax = 0;
    for(int i = 1; i< k;i++){
        if(a[i].distancia > a[posMax].distancia){
            posMax = i;
        }
    }
    return posMax;
}
